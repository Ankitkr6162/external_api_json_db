package io.spring.json.parse.db.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import io.spring.json.parse.db.entities.User;
import io.spring.json.parse.db.repositories.UserRepository;

@Service
public class UserService {

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private UserRepository userRepository;
	
	public void fetchDataAndSaveToDatabase() {
		
		String apiUrl = "https://jsonplaceholder.typicode.com/comments";
		
		ResponseEntity<User[]> responseEntity = restTemplate.getForEntity(apiUrl, User[].class);
		User[] users = responseEntity.getBody();
		
		if (users != null) {
			for(User user : users) {
				
				userRepository.save(user);
				
			}
		}
		
	}
}
