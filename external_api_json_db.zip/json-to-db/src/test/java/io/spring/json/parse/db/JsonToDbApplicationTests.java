package io.spring.json.parse.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonToDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
